Page({
  data: {
    showModal: false,
    inputValue: ''
  },
  bindKeyInput: function (e) {
    this.setData({
      inputValue: e.detail.value/*获取用户输入*/
    })
    getApp().globalData.deftarget = this.data.inputValue/*记录用户输入*/
  },
  /**
   * 弹窗
   */
  showDialogBtn: function () {
    this.setData({
      showModal: true
    })
  },
  /**
   * 弹出框蒙层截断touchmove事件
   */
  preventTouchMove: function () {
  },
  pulse:function(event){
    wx.navigateTo({
      url: '../beat/beat',
    })
    console.log(event)
  },
  /**
   * 隐藏模态对话框
   */
  hideModal: function () {
    this.setData({
      showModal: false
    });
  },
  /**
   * 对话框取消按钮点击事件
   */

  /**
   * 对话框确认按钮点击事件
   */
  onCancel: function () {
    //var test = getApp().globalData.deftarget;
    //console.log(test)
    this.hideModal();
  },
  back: function (event) {
    var test = getApp().globalData.deftarget;
    console.log(test)
    wx.navigateTo({
      url: '../run/run',
    })
    console.log(event)
  },


})








